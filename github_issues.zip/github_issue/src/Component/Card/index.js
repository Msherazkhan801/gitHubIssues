import * as React from "react";
import {Card,} from "@mui/material";
import CardContent from "@mui/material/CardContent";
import IssuesTable from "../IssuesTable";
import { useState,useEffect,useCallback } from "react";
import { getIssues } from "../../services/Api/API";
import {getMaxPageFromHeader} from "../../Helper/Helper"
const sxStyle={
    minWidth: 575,
     minHeight: 875,
      maxHeight: 875 ,
      marginTop: "50px" 
}

export default function Container() {
    
  const [loading, setLoading] = useState(false);
  const [organization, setOrganization] = useState("facebook");
  const [project, setProject] = useState("create-react-app");
  const [issues, setIssues] = useState([]);
  const [page, setPage] = useState(1);
  const [maxPage, setMaxPage] = useState(1);
  const [state, setState] = useState("open");
  const [author, setAuthor] = useState(null);
  const [assignee, setAssignee] = useState("");
  const [labels, setLabels] = useState([]);
  const [error, setError] = useState(null);
  const [sortBy, setSortBy] = useState("created");
  const [sortDirection, setSortDirection] = useState("desc");
  const [milestone, setMilestone] = useState(null);

console.log(error);
  useEffect(() => {
    getGithubIssues();
  }, [
    page,
    state,
    author,
    labels,
    assignee,

    sortBy,
    sortDirection,
    milestone,
   
  ]);
  const getGithubIssues = useCallback(() => {
    setLoading(true);
    getIssues(
      organization,
      project,
      page,
      5,
      state,
      author,
      labels,
      assignee,
      sortBy,
      sortDirection,
      milestone,
   
    )
      .then(data => {
        // console.log(data.data);
        setIssues(data.data);
        setError(null);
        setLoading(false);
        if (data.linkHeader) {
          let max = getMaxPageFromHeader(data.linkHeader);
          max = max === -1 ? page : max === 0 ? maxPage : max;
          setMaxPage(max);
        }
      })
      .catch(err => {
        setError(err);
        setLoading(false);
      });
  }, [
    organization,
    project,
    page,
    state,
    author,
    labels,
    assignee,
    sortBy,
    sortDirection,
    milestone,
    
  ]);

  const onPrev = () => {
    if (page <= 1) {
      return;
    }
    setPage(page - 1);
  };

  const onNext = () => {
    setPage(page + 1);
  };

  const onPage = page => {
    setPage(page);
  };

  const stateChanged = state => {
    setState(state);
    setPage(1);
  };

 

  const onAuthorChange = author => {
    setAuthor(author);
  };

  const onLabelsChange = labels => {
    setLabels(labels);
  };

  const onLabelChanged = label => {
    setLabels([label]);
  };

  const onAssigneeChange = assignee => {
    setAssignee(assignee);
  };

  const onSortingChange = event => {
    if (event.sortBy !== sortBy) {
      setSortBy(event.sortBy);
    }
    if (event.sortDirection !== sortDirection) {
      setSortDirection(event.sortDirection);
    }
  };

  const onMilestonesChange = event => {
    setMilestone(event);
  };

  const onRepoChange = event => {
    setProject(event);
  };

  const onOrgChange = event => {
    setOrganization(event);
  };

  const onClearFilters = event => {
    setLabels([]);
    setSortBy("created");
    setSortDirection("desc");
    setMilestone(undefined);
    setAuthor(undefined);
    setAssignee(undefined);
  };

  return (
    <Card
      sx={sxStyle} 
    >
      <CardContent>
       <IssuesTable  
      issues={issues}
      project={project}
      organization={organization}
      loading={loading}
      onLabelSelected={onLabelChanged}
      onAuthorSelected={onAuthorChange}
      page={page}
      maxPage={maxPage}
      loading={loading}
      onPrev={onPrev}
      onNext={onNext}
      onPage={onPage}
      
      />
       
          
      
      </CardContent>
    </Card>
  );
}
