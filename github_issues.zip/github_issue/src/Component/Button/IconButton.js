import * as React from 'react';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import LoyaltyIcon from '@mui/icons-material/Loyalty';
import CommitIcon from '@mui/icons-material/Commit';
import { toast } from 'react-toastify';
const btn={
    background:"F0EBE3",
    border:"0.5px solid black"
}
export default function IconLabelButtons({text,milestone}) {
  return (
    <Stack direction="row" spacing={2}>
      <Button sx={btn} startIcon={<LoyaltyIcon />} onClick={()=>{toast.info("Click below Lable button")}}>
       {text}<span style={{marginLeft:"5px" ,background:"#D6EFED",borderRadius:"50px",minWidth:"20px",padding:"0 6px"}}>3</span>
      </Button>
      <Button sx={btn} startIcon={<CommitIcon />} onClick={()=>{toast.info("Click below Milstone button")}}>
        {milestone}<span style={{marginLeft:"5px" ,background:"#D6EFED",borderRadius:"50px",minWidth:"20px",padding:"0 6px"}}>6</span>
      </Button>
    </Stack>
  );
}
