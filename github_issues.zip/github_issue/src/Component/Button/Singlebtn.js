import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import { toast } from 'react-toastify';
const btn={
    background:"#2da44e",
    // border:"0.5px solid black",
    marginLeft:"5px",
    color:"#fff",
    
    
}

export default function BasicButtons({Text}) {
  return (
    <Stack spacing={2} direction="row">
      <Button sx={btn} variant="contained" onClick={()=>{toast.success("New issue Added")}}>{Text}</Button>
    </Stack>
  );
}
