import React from "react";
import ListItem from "../ListItem/ListItem";
import "./List.css";
import CachedIcon from '@mui/icons-material/Cached';

function List(props) {
  return (
    <div className="list-container">
      {props.filteredVal &&  props.filteredVal.map(issue => (
        <ListItem
          key={issue.id}
          issue={issue}
          project={props.project}
          organization={props.organization}
          onLabelSelected={props.onLabelSelected}
          onAuthorSelected={props.onAuthorSelected}
        />
      ))}
      {props.loading && (
        <div className="loader">
          <div className="spinner">
            <CachedIcon
              className="spinner-icon"
              icon="spinner"
              color="#000000"
            />
            <span>Loading</span>
          </div>
        </div>
      )}
    </div>
  );
}

export default List;
