import * as React from "react";
import { styled } from "@mui/material/styles";

import { TextField } from "@mui/material";
const Searchs = styled("div")(({ theme }) => ({
  minWidth: 630,
  minHeight: 30,
  marginRight: "20px",
  // marginTop:"20px"
  [theme.breakpoints.down("md")]: {
    minWidth: 530,
    minHeight: 30,
    marginRight: "20px",
    marginTop: "20px",
    marginBottom:"20px"
  },
  [theme.breakpoints.down("sm")]: {
    minWidth: 230,
    minHeight: 20,
    marginRight: "20px",
    marginTop: "20px",
    marginBottom:"20px",
    
  },
}));

export default function Search({ issues, search, setSearch }) {
  return (
    <Searchs>
      <TextField
        placeholder="is:issue is:open"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        sx={{ minWidth: "100%", minHeight: 30 }}
      />
    </Searchs>
  );
}
