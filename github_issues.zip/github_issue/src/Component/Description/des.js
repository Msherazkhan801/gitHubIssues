import * as React from "react";
import {Card,Typography,Box, Button} from "@mui/material";
import CardContent from "@mui/material/CardContent";
import { useState,useEffect,useCallback } from "react";
import { getIssues } from "../../services/Api/API";
import {getMaxPageFromHeader} from "../../Helper/Helper"
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import {  useNavigate, useParams } from "react-router-dom";





const sxStyle={
    minWidth: 575,
     minHeight: 875,
      maxHeight: 875 ,
      marginTop: "50px" 
}

const box = {
  minWidth: 1175,
  maxWidth: 875,
  minHeight: 635,
  maxHeight: 675,
  margin: "20px auto",
  // border: "1px solid black",
};

const childwrapers = {
    display: "flex", 
  border: "0.2px solid #a89f9e",
  minHeight: 50,    
  width:"100%"
};

const Des = () => {
     
    const [loading, setLoading] = useState(false);
    const [organization, setOrganization] = useState("facebook");
    const [project, setProject] = useState("create-react-app");
    const [issues, setIssues] = useState([]);
    const [page, setPage] = useState(1);
    const [maxPage, setMaxPage] = useState(1);
    const [state, setState] = useState("open");
    const [author, setAuthor] = useState(null);
    const [assignee, setAssignee] = useState("");
    const [labels, setLabels] = useState([]);
    const [error, setError] = useState(null);
    const [sortBy, setSortBy] = useState("created");
    const [sortDirection, setSortDirection] = useState("desc");
    const [milestone, setMilestone] = useState(null);
  
  console.log(error);
    useEffect(() => {
      getGithubIssues();
    }, [
      page,
      state,
      author,
      labels,
      assignee,
  
      sortBy,
      sortDirection,
      milestone,
     
    ]);
    const getGithubIssues = useCallback(() => {
      setLoading(true);
      getIssues(
        organization,
        project,
        page,
        5,
        state,
        author,
        labels,
        assignee,
        sortBy,
        sortDirection,
        milestone,
     
      )
        .then(data => {
          // console.log(data.data);
          setIssues(data.data);
          setError(null);
          setLoading(false);
          if (data.linkHeader) {
            let max = getMaxPageFromHeader(data.linkHeader);
            max = max === -1 ? page : max === 0 ? maxPage : max;
            setMaxPage(max);
          }
        })
        .catch(err => {
          setError(err);
          setLoading(false);
        });
    }, [
      organization,
      project,
      page,
      state,
      author,
      labels,
      assignee,
      sortBy,
      sortDirection,
      milestone,
      
    ]);
  
  const Navigate=useNavigate()
  
const {id}=useParams()
const findObj = issues && issues.length > 0 && issues.find(item => {
    return item.id!==id

})
// console.log(id,"<==id");

  return (
    <>
      <Card sx={sxStyle}  >
      <Typography variant="h3" component="h3" style={{ textAlign: "center" }}>
        Github’s Issue page Detail
      </Typography>
      <CardContent>
        <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>User</TableCell>
            <TableCell align="left">Title</TableCell>
            <TableCell align="left">Comments</TableCell>
            <TableCell align="left">State</TableCell>
            <TableCell align="left">Milestone</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {/* {findObj?.map((row) => ( */}
            <TableRow
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                <img src={findObj?.user?.avatar_url} alt="pic" style={{width:"50px",height:"50px",borderRadius:"50px"}}/>
              </TableCell>
              <TableCell align="left">{findObj?.title}</TableCell>
              <TableCell align="left">{findObj?.comments}</TableCell>
              <TableCell align="left">{findObj?.state}</TableCell>
              <TableCell align="left">{findObj?.milestone?findObj?.milestone:"null"}</TableCell>
            </TableRow>
          {/* ))} */}

        </TableBody>
      </Table>
    </TableContainer>
          <Box sx={{minHeight:"50vh",border:"1px solid black"}}>
            <Typography  variant="h3" component="h3" sx={{textAlign:"center",marginTop:"80px",fontWeight:"bold"}}>
            No More results matched your search.
            </Typography>
            <Typography  variant="p" component="p" sx={{textAlign:"center",marginTop:"80px",fontWeight:"bold"}}>
            You could <a href="https://github.com/pulls/review-requested">search </a> all of GitHub or try an <a href="https://github.com/pulls/review-requested">advanced search. </a>
            </Typography>
          </Box>
          <Button onClick={()=>{Navigate("/")}} variant="contained" >Home</Button>
      
      </CardContent>
    </Card>
    </>
  );
};

export default Des;
