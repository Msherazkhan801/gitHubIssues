import { Box,  Typography } from "@mui/material";
import React,{useState} from "react";
import Search from "../Search";
import Buttons from "../Button";
import BasicButtons from "../Button/Singlebtn";
import IconLabelButtons from "../Button/IconButton";
import List from "../Issue List/List/List"
import Headers from "../Header /ListHeader"
import Pagination from "../Pegination/Pegination"
import {styled} from "@mui/material/styles"
const Responsive=styled('div')(({theme})=>({

  display: "flex",
  justifyContent: "center" ,
  
  [theme.breakpoints.down('md')]:{
    display:"bolck",
    display:'flex',
    flexDirection:"column",
    marginTop:"20px"
    // background:"#000"
  },

}))

const ListData =styled('div')(({theme})=>({ 
  minWidth: 1175,
  maxWidth: 875,
  minHeight: 635,
  maxHeight: 675,
  margin: "20px auto",
  // border: "1px solid black",
  [theme.breakpoints.down('md')]:{
  minWidth: 575,
  maxWidth: 875,
  minHeight: 635,
  maxHeight: 675,
  },
  [theme.breakpoints.down('sm')]:{
    minWidth: 475,
    maxWidth: 575,
    minHeight: 635,
    maxHeight: 675,
    },

}))

// const buttonBox={

// }

const childwrapers = {
    display: "flex", 
  border: "0.2px solid #a89f9e",
  minHeight: 50,    
  width:"100%"
};
const button={
  display: "flex",
  justifyContent: "center" ,
 
}

const IssuesTable = (props) => {
  const [search ,setSearch]=useState("")
  let filteredVal = props.issues && props.issues.length > 0 && props.issues.filter((item, i) => {
    return item && item.title && item.title.toLowerCase().includes(search)
  })
  console.log(filteredVal,"<===");

  return (
    <>
      <Typography variant="h3" component="h3" style={{ textAlign: "center" }}>
        Github’s Issues page
      </Typography>
      <Responsive >
        <Buttons text="filter" />
        <Search   
            issues={props.issues}
            search={search} 
            setSearch={setSearch}
        
        />
        <Box sx={button}>
        <IconLabelButtons text="Lable" milestone="MileStone" />
        <BasicButtons Text="new issue"  />
        </Box>
      </Responsive>
      <ListData >
       <Box sx={childwrapers}>
       <Headers/>
        </Box>   
        <List
            issues={props.issues}
            project={props.project}
            organization={props.organization}
            loading={props.loading}
            onLabelSelected={props.onLabelChanged}
            onAuthorSelected={props.onAuthorChange}
            filteredVal={filteredVal}
          />
            <Pagination
            page={props.page}
            maxPage={props.maxPage}
            loading={props.loading}
            onPrev={props.onPrev}
            onNext={props.onNext}
            onPage={props.onPage}
            
          />
      </ListData>
    </>
  );
};

export default IssuesTable;
