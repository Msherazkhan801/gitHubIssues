import * as React from 'react';
import Box from '@mui/material/Box';
import Skeleton from '@mui/material/Skeleton';

export default function PreLoading() {
  return (
    <Box sx={{ width: 1400 }} style={{margin:" 100px auto"}}>
      <Skeleton />
      <Skeleton animation="wave" />
      <Skeleton animation={true} />
      <Skeleton />
      <Skeleton animation="wave" />
      <Skeleton animation={true} />
      <Skeleton />
      <Skeleton animation="wave" />
      <Skeleton animation={true} />
      <Skeleton />
      <Skeleton animation="wave" />
      <Skeleton animation={true} />
      <Skeleton />
      <Skeleton animation="wave" />
      <Skeleton animation={true} />
      <Skeleton />
      <Skeleton animation="wave" />
      <Skeleton animation={true} />
      <Skeleton animation={true} />
      <Skeleton />
      <Skeleton animation="wave" />
      <Skeleton animation={true} />
      <Skeleton />
      <Skeleton animation="wave" />
      <Skeleton animation={true} />
      <Skeleton />
      <Skeleton animation="wave" />
      <Skeleton animation={true} />
      <Skeleton />
      <Skeleton animation="wave" />
      <Skeleton animation={true} />
    </Box>
  );
}
