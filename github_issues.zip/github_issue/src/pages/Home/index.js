import React from 'react'
import Container from '../../Component/Card'
// import ListHeader from "../../Component/Header /ListHeader"

const Home = () => {
    return (
        <div className="container">
            {/* <ListHeader/> */}
            <Container/>

            
        </div>
    )
}

export default Home
