import React from 'react'
import Des from '../../Component/Description/des'

const Description = () => {
    return (
        <div>
            <Des/>
        </div>
    )
}

export default Description
