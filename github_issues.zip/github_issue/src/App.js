import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './App.css';
import Home from './pages/Home';
import Description from './pages/Description';
import {
  BrowserRouter as Router,
  Routes,
  Route,

} from "react-router-dom";
function App() {
  return (
    <div className="App">
      <Router>

     <div className="Appchild">
     <ToastContainer
     position="top-right"
     autoClose={3000}
     hideProgressBar={false}
     />
     <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/:id" element={<Description/>}/>
      
     </Routes>
       </div>   
     </Router>
    </div>
  );
}

export default App;
